const addButtonsToImage = (img) => {
  if (img.classList.contains('processed-image')) return;
  img.classList.add('processed-image');

  const btnGroup = document.createElement('div');
  btnGroup.className = 'img-save-btn-group-overlay';

  btnGroup.innerHTML = `
    <button class="save-btn-action" title="Mentés">💾</button>
    <button class="settings-btn-action" title="Beállítások">⚙️</button>
  `;

  document.body.appendChild(btnGroup);

  const updatePosition = () => {
    const rect = img.getBoundingClientRect();
    const scrollTop = window.scrollY || window.pageYOffset || document.documentElement.scrollTop;
    const scrollLeft = window.scrollX || window.pageXOffset || document.documentElement.scrollLeft;

    // Ha a kép nem látható a képernyőn, ne is mutassuk a gombot
    if (rect.width < 30 || rect.height < 30) {
      btnGroup.style.display = 'none';
      return;
    }

    btnGroup.style.display = 'flex';
    btnGroup.style.top = `${rect.top + scrollTop + 5}px`;
    btnGroup.style.left = `${rect.right + scrollLeft}px`;
  };

  // Láthatóság vezérlése
  const showButtons = () => {
    updatePosition();
    btnGroup.style.opacity = '1';
    btnGroup.style.visibility = 'visible';
  };

  const hideButtons = (e) => {
    // Csak akkor rejtjük el, ha nem a gombokra léptünk át
    if (!btnGroup.contains(e.relatedTarget)) {
      btnGroup.style.opacity = '0';
      btnGroup.style.visibility = 'hidden';
    }
  };

  img.addEventListener('mouseenter', showButtons);
  img.addEventListener('mouseleave', hideButtons);
  btnGroup.addEventListener('mouseleave', hideButtons);

  // Gomb események
  btnGroup.querySelector('.save-btn-action').onclick = (e) => {
    e.preventDefault();
    const btn = e.target;
    const originalIcon = btn.innerHTML;

    chrome.runtime.sendMessage({ action: "downloadImage", url: img.src });

    // Vizuális visszajelzés: az ikon átvált egy pipára 2 másodpercre
    btn.innerHTML = '✅';
    setTimeout(() => {
      btn.innerHTML = originalIcon;
    }, 2000);
  };

  btnGroup.querySelector('.settings-btn-action').onclick = (e) => {
    e.preventDefault();
    browser.runtime.sendMessage({ action: "openOptions" });
  };
};

// Egérfigyelő az újonnan megjelenő képekhez
document.addEventListener('mouseover', (e) => {
  if (e.target.tagName === 'IMG') {
    addButtonsToImage(e.target);
  }
}, true);