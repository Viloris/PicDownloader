chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "downloadImage") {
    const filename = "mentett_kepek/" + request.url.split('/').pop().split('?')[0];

    chrome.downloads.download({
      url: request.url,
      filename: filename, // Ez a 'Downloads' mappán belül hozza létre
      conflictAction: "uniquify"
    });
  }
});