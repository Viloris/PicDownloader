// Keressük meg az összes képet az oldalon
const addDownloadButtons = () => {
  const images = document.querySelectorAll('img:not(.processed-image)');

  images.forEach(img => {
    img.classList.add('processed-image');

    // Kell egy konténer, hogy a gombot pozicionálni tudjuk
    const wrapper = document.createElement('div');
    wrapper.className = 'img-save-wrapper';

    // Az eredeti kép helyére beszúrjuk a wrapper-t
    img.parentNode.insertBefore(wrapper, img);
    wrapper.appendChild(img);

    // Létrehozzuk a letöltő gombot
    const btn = document.createElement('button');
    btn.innerHTML = '💾'; // Ide jöhet egy kis ikon képe is
    btn.className = 'save-img-btn';

    wrapper.appendChild(btn);

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();

      // Küldjük el a kép URL-jét a background scriptnek
      chrome.runtime.sendMessage({
        action: "downloadImage",
        url: img.src
      });
    });
  });
};

// Figyeljük az újonnan betöltődő képeket is (pl. görgetésnél)
const observer = new MutationObserver(addDownloadButtons);
observer.observe(document.body, { childList: true, subtree: true });

// Első futtatás
addDownloadButtons();