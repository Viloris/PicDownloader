const DEFAULT_FOLDER = "Képek/BővítményMentések";

// Amikor megnyitjuk az opciókat, betöltjük a mentett vagy az alapértelmezett értéket
chrome.storage.sync.get(['targetFolder'], (result) => {
    document.getElementById('folderName').value = result.targetFolder || DEFAULT_FOLDER;
});

// Mentés gomb
document.getElementById('save').addEventListener('click', () => {
    const folder = document.getElementById('folderName').value;
    chrome.storage.sync.set({ targetFolder: folder }, () => {
        alert('Beállítások elmentve!');
    });
});